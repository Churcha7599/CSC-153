﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        /**
         * Date
         * CSC153
         * Aaron Church
         * This demo an array with a set number of sales(elements)
         */
        static void Main(string[] args)
        {
            double[] sales = new double[7];

            sales[0] = 1245.67;
            sales[1] = 1189.55;
            sales[2] = 1098.72;
            sales[3] = 1456.88;
            sales[4] = 2109.34;
            sales[5] = 1987.55;
            sales[6] = 1872.36;

            for (int i = 0; i < sales.Length; i++)
            {
                Console.WriteLine(sales[i]);                
            }

            Console.ReadLine();
            
        }
    }
}
