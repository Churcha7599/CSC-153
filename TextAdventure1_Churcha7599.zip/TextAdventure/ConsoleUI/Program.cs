﻿using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        public static object Entance { get; private set; }
        public static object Anteroom { get; private set; }
        public static object Hall { get; private set; }
        public static object Dungeon { get; private set; }
        public static object BossRoom { get; private set; }
        public static object Axe { get; private set; }
        public static object Sword { get; private set; }
        public static object Bow { get; private set; }
        public static object Spear { get; private set; }
        public static object Healing { get; private set; }
        public static object Mana { get; private set; }
        public static object Necklace { get; private set; }
        public static object Ring { get; private set; }
        public static object Chalice { get; private set; }
        public enum Directions
        {
            North, South
        };

        public static string[] shortDirections = { "N", "S" };
        private Location leadsTo;
        private Directions direction;
        static void Main(string[] args)
        {
            object[] rooms = new object[4];
            rooms[0] = Entance;
            rooms[1] = Anteroom;
            rooms[2] = Hall;
            rooms[3] = Dungeon;
            rooms[4] = BossRoom;

            object[] weapons = new object[3];
            weapons[0] = Axe;
            weapons[1] = Sword;
            weapons[2] = Bow;
            weapons[3] = Spear;

            object[] potion = new object[1];
            potion[0] = Healing;
            potion[1] = Mana;

            object[] treasure = new object[2];
            treasure[0] = Necklace;
            treasure[1] = Ring;
            treasure[2] = Chalice;

            List<string> items = new List<string>();
            Item key = new Item();
            Item orb = new Item();
            Item idle = new Item();
            Item statue = new Item();

            List<string> Mods = new List<string>();

            Console.WriteLine("Welcome to my text adventuer");

            object r1 = new room("Begin at the ENTRANCE");
            object r2 = new rooms("Entrance of Anteroom, this is where you will customize any gear you currently have or obtained. ");
            object r3 = new rooms("Enter the Hall");
            object r4 = new rooms("The DUNGEON is near");
            object r5 = new rooms("This is the final room, also known where the boss lurks");

            r1.addExit(new Exit(Exit.Direction.North, r2));
            r1.addExit(new Exit(Exit.Direction.South, null));

            r2.addExit(new Exit(Exit.Direction.North, r3));
            r2.addExit(new Exit(Exit.Direction.South, r1));

            r3.addExit(new Exit(Exit.Direction.North, r4));
            r3.addExit(new Exit(Exit.Direction.South, r2));

            r4.addExit(new Exit(Exit.Direction.North, r5));
            r4.addExit(new Exit(Exit.Direction.South, r3));

            r5.addExit(new Exit(Exit.Direction.North, null));
            r5.addExit(new Exit(Exit.Direction.South, r4));
        } 
    }
}
