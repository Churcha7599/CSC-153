﻿namespace ConsoleUI
{
    internal class Exit
    {
        private object north;
        private object south;
        private object r2;

        public Exit(object north, object r2)
        {
            this.north = north;
            south = south;

            this.r2 = r2;
        }

        public static object Direction { get; internal set; }
    }
}