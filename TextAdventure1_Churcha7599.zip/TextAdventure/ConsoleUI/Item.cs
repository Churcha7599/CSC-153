﻿namespace ConsoleUI
{
    internal class Item
    {

    }
}