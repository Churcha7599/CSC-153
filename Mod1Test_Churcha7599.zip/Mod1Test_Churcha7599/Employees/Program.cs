﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employees
{
    /**
     * 2/5/2020
     * CSC153
     * Aaron Church
     * Mod1Test_Churcha7599
     */
    class Program
    {
        private const int V = 0;
        private static object numbers;
        public static object Constant { get; set; }
        public static string Forty { get; private set; }
        public static string Twenty { get; private set; }

        static void Main(string[] args)
        {

            int Aaron = 0;
            string[] names = new string[Aaron];
            double[] number = new double[1];
            number[1] = 910.6782321;
            var age = new List<string>() { "Ten", "Twenty", "Thirty", "Forty" };
            age[2] = Forty;
            age[3] = Twenty;

            {
                Console.WriteLine(names[0]);
                Console.WriteLine(number[1]);
                for (int index = 0; index < numbers.Count(); index++);
                {
                    Console.WriteLine($"There are {numbers.Count} values in the list");
                }
                
            }
            

        }
    }
}
